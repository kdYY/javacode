package cn.sinobest.ggjs.strategy.basic.util;

public class StringUtils {
	public static boolean isNullOrEmpty(String str) {
		return ((str == null) || (str.length() == 0));
	}
}
package cn.sinobest.ggjs.strategy.basic.builder;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import cn.sinobest.ggjs.strategy.core.builder.InjectCheckPointBuilder;
import cn.sinobest.ggjs.strategy.builder.AbstractBuilder;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;
import cn.sinobest.ggjs.strategy.core.utils.FileUtil;

public class CopyBuilder extends AbstractBuilder {

	public CopyBuilder(){}

	public CopyBuilder(PackageInfo packageInfo, StrategyInfo strategyInfo) {
		this.packageInfo = packageInfo;
		this.strategyInfo = strategyInfo;
	}

	/**
	 * copy the inserted verifyjar to target jar
	 * @return
	 * @throws Exception
	 */
	@Override
	public PackageInfo build() throws Exception {

		//the same level  as user's jar uploaded directory. like user's jar location is '**/test/userJar' and licFilePath is '**/test'
//		String licFilePath =packagePath+File.separator+ "license.lic";
		//TODO remove it
//		System.out.println("lic的路径为"+licFilePath);

//		String targetLicFilePath = targetPath +
//				File.separator + "BOOT-INF" + File.separator + "classes" + File.separator+ "license.lic";

		// copy .lic
//		FileUtil.copyFile(new File(licFilePath), new File(targetLicFilePath));

		//约定一个license的路径

		//copy log4j to target jar？？？？？
//		FileUtil.copyFile(new File(libPath
//				+ File.separator
//				+ "log4j.jar"),
//				new File(packageInfo.getTargetPath()
//				+ File.separator
//				+ "BOOT-INF"+File.separator+"lib"
//				+ File.separator
//				+ "sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar"));
		String targetPath = packageInfo.getTargetPath();
		// set public key
		String verifyJarName = "sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar";
		File file = new File(targetPath);
		if(!file.exists()){
		    throw new RuntimeException("targetPath not found");
        }
        String copySrc = verifyInjectCode();
		FileUtil.copyFile(
		        new File(copySrc),
                new File(targetPath + File.separator + "BOOT-INF"+File.separator+"lib"
                + File.separator
                + verifyJarName));

		return packageInfo;
	}

	/**
	 * insert the public key to the verify jar
	 * @return the new verify jar File path
	 * @throws Exception
	 */
	public String verifyInjectCode() throws Exception {
		String targetPath = packageInfo.getTargetPath();
		String libPath = FileUtil.getLibPath();
		// set public key
		String verifyJarName = "sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar";
		String VerifyJarPath = libPath + File.separator + verifyJarName;
		//get the path where the verify jar in
		File file2 = new File(targetPath);
		String targetVerifyJarPath = file2.getParentFile().getAbsolutePath() + File.separator +
				verifyJarName.substring(0,verifyJarName.indexOf(".jar"));
		//release the target jar
		FileUtil.unJar(new File(VerifyJarPath), new File(targetVerifyJarPath));
		//set the license private key
		String VclassToChange = "cn.sinobest.ggjs.strategy.StrategyVerify";
		String VmethodName = "initE";
		String VinsertWord = "try {\n" +
				"            this.e = cn.sinobest.ggjs.strategy.basic.util.ByteHex.convert(\""+strategyInfo.getPublicKey()+"\");\n" +
				"        } catch (Exception var5) {\n" +
				"            var5.printStackTrace();\n" +
				"        }";
		InjectCheckPointBuilder insertVerify = new InjectCheckPointBuilder(targetVerifyJarPath,VclassToChange,VmethodName,VinsertWord,targetVerifyJarPath);
		insertVerify.build();

		String CompressSrc = targetVerifyJarPath;
		File file = new File(targetPath);
		if(!file.exists()){
			throw new RuntimeException("targetPath not found");
		}
		String CompressDes = file.getParentFile().getAbsolutePath()+File.separator+ verifyJarName;
		//place the verify jar to target jar
		FileUtil.compressJarByCommond(CompressSrc, CompressDes);
		return CompressDes;
	}



	
}

package cn.sinobest.ggjs.strategy.core.builder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.jar.JarFile;

import cn.sinobest.ggjs.strategy.core.utils.FileUtil;
import javassist.*;
import org.apache.log4j.Logger;
import cn.sinobest.ggjs.strategy.builder.AbstractBuilder;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;

public class InjectCheckPointBuilder extends AbstractBuilder {

	private static final Logger LOGGER = Logger.getLogger(InjectCheckPointBuilder.class);

	private ClassPool classPool;

	private ArrayList<String> classFilePath = new ArrayList<>();
	private ArrayList<ClassPath> classPathList = new ArrayList<>();
	private String className;
	private String methodName;
	private String injectCode;
	private String unpackPath;
	private String outputPath;
	
	public InjectCheckPointBuilder(String unpackPath, String className, String methodName, String injectCode, String outputPath ) {
		this.className = className;
		this.methodName = methodName;
		this.injectCode = injectCode;
		this.unpackPath = unpackPath;
		this.outputPath = outputPath;
        this.classPool = new ClassPool(true);
		classFilePath = FileUtil.findClassPath(unpackPath);
	}

	/**
    *
    * @param classPath
    * @param className 要修改的类路径
    * @param methodName 要修改的方法名
    * @param injectCode   插入的代码
    * @param outputPath    新类输出的路径
    * @throws Exception
    */
   public  void injectCheckCode(ArrayList<String> classPath, String className, String methodName, String injectCode, String outputPath) throws Exception{
       try {
    	   
    	   this.classFilePath = FileUtil.findClassPath(unpackPath);
    	   CtClass class0 = this.init(classFilePath, className);
//           CtClass class0 = init(classPath, className);
    	   
           CtMethod method = class0.getDeclaredMethod(methodName);
           method.insertBefore(injectCode);
           //输出到文件
           class0.writeFile(outputPath);
           //CtClass对象将从ClassPool中移除
           class0.detach();
           this.releaseClassPool();
           //help to gc
           classPool = null;

       } catch (NotFoundException e1) {
           throw new RuntimeException(e1.getMessage());
       } catch (CannotCompileException e2) {
           throw new RuntimeException(e2.getMessage());
       } catch (IOException e3) {
           throw new RuntimeException(e3.getMessage());
       }
   }
   
	/**
     * 根据classPath构建CtClass
     * @param classPath
     * @param className
     * @return
     */
    public CtClass init(ArrayList<String> classPath, String className)throws Exception{
        try {
            classPool.insertClassPath(classPath.get(0));
            if (classPath.size() > 1) {
                for (int i = 1; i < classPath.size(); i++) {
                    try {
                        classPathList.add(classPool.appendClassPath(classPath.get(i)));
                    }catch (Exception e){
                        //不处理
                        System.out.println(classPath.get(i));
                        e.printStackTrace();
                    }
                }
            }
            return classPool.get(className);
        } catch (NotFoundException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
    
	@Override
	public PackageInfo build() throws Exception {
		injectCheckCode(classFilePath, className, methodName, injectCode, outputPath);
		LOGGER.info(className + " has injectCheckPoint");
		return this.packageInfo;
	}

	public void releaseClassPool(){
        classPathList.forEach(classpath->{
            try {
                this.classPool.removeClassPath(classpath);
            }catch (NullPointerException e1){
                //不处理

            }
        });
    }

    public static void main(String[] args) throws Exception {
        String a = "C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-manager-0.1.0-SNAPSHOT-exec";
        String path = "C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-manager-0.1.0-SNAPSHOT-exec\\BOOT-INF\\classes";
        String injectCode = "    \ttry {\n    \t\tif (!cn.sinobest.ggjs.strategy.StrategyVerify.getInstance().isValid()) {\n\tlogger.error(\"***********the license file is invalid (authentication is invalid or license file is expired), the system will exit!!!\");        \t\tSystem.exit(-1);\n    \t\t}\n    \t} catch (Throwable e) {\n\tlogger.error(\"***********the license file is invalid (authentication is invalid or license file is expired), the system will exit!!!\");    \t\tSystem.exit(-1);\n    \t}";

        InjectCheckPointBuilder main = new InjectCheckPointBuilder(a, "cn.sinobest.sinogear.SinoGearExampleApp", "main", injectCode, path);
        main.build();

        JarFile f = new JarFile("C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-manager-0.1.0-SNAPSHOT-exec\\BOOT-INF\\classes\\dataImportPackage\\sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar");
        System.out.println("test");
    }



}

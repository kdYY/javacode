package cn.sinobest.ggjs.strategy.core.HotSpotSwap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;

/**
 * 将策略包jar用StrategyClassLoader进行加载，实现热卸载，
 * 2.0 版本实现热替换
 */
public class StrategyClassLoader extends URLClassLoader {
    //去指定路径搜索配置文件，jar 名字是否变化
    // 名字相同&&modifytime变化了 reload class
    //名字不同 卸载所有，并重新load jar
    private static String strategypath;
//    private static String projectClassPath = Thread.currentThread().getContextClassLoader().getResource("").getFile();
    //缓存加载class
    public static Map<String,Class> cacheClassMap = new HashMap<>();
    //缓存加载实例域
    public static Map<String,Object> cacheFieldMap = new HashMap<>();

    //要求被父类加载的类
    public static List<String> interfaceLoadByClass;

    static {
          strategypath = "C:\\Users\\yaokaidong\\Desktop\\new\\sinobest-licence-strategy-basic-0.0.1-SNAPSHOT.jar";
        interfaceLoadByClass = Arrays.asList(new String[]{
                "cn.sinobest.ggjs.strategy.builder.AbstractBuilder",
                "cn.sinobest.ggjs.strategy.domain.PackageInfo",
                "cn.sinobest.ggjs.strategy.domain.StrategyInfo",
                "cn.sinobest.ggjs.strategy.AbstractService",
                "cn.sinobest.ggjs.strategy.AbstractStrategy",
        "cn.sinobest.ggjs.strategy.InjectCheckPointBuilder"});
    }


    public StrategyClassLoader() {
        super(getMyURLs());
    }

    private static  URL[] getMyURLs(){
        URL url = null;
        try {
            url = new File(strategypath).toURI().toURL();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return new URL[] { url };
    }

    @Override
    public Class<?> loadClass(String name,boolean resolve) throws ClassNotFoundException {
        Class clazz = null;
        //查看StrategyClassLoader实例缓存下，是否已经加载过class
        //不同的StrategyClassLoader实例是不共享缓存的
        clazz = findLoadedClass(name);
        if (clazz != null ) {
            if (resolve){
                resolveClass(clazz);
            }

            return clazz;
        }
        //如果类的包名为"java."开始，则有系统默认加载器AppClassLoader加载
        if(name.startsWith("java.") || exist(name)){
            try {
                //得到系统默认的加载cl，即AppClassLoader
                ClassLoader system = ClassLoader.getSystemClassLoader();
                clazz = system.loadClass(name);
                if (clazz != null) {
                    if (resolve)
                        resolveClass(clazz);
                    return (clazz);
                }
            } catch (ClassNotFoundException e) {
                // Ignore
            }
        }

        //otherwise, using customload
        return customLoad(name,false,this);
    }

    private boolean exist(String name) {
        return interfaceLoadByClass.contains(name);
    }


    /**
     * 自定义加载
     * @param name
     * @param resolve
     * @return
     * @throws ClassNotFoundException
     */
    public Class customLoad(String name, boolean resolve,ClassLoader cl) throws ClassNotFoundException {
        //findClass()调用的是URLClassLoader里面重载了ClassLoader的findClass()方法
        Class clazz = ((StrategyClassLoader)cl).findClass(name);
        if (resolve)
            ((StrategyClassLoader)cl).resolveClass(clazz);
        //缓存在此classloader加载的class
        cacheClassMap.put(name,clazz);
        return clazz;
    }


    //处理
    @Override
    protected Class<?> findClass(String name) {
        // findClass实现了class文件搜索和load
        Class<?> aClass = null;
        try {
            aClass = super.findClass(name);
        } catch (ClassNotFoundException e) {
            if(aClass == null){
                ClassLoader system = ClassLoader.getSystemClassLoader();
                Class clazz = null;
                try {
                    clazz = system.loadClass(name);
                } catch (ClassNotFoundException e1) {

                }
                return (clazz);
            }
        }

        return aClass;
    }

    @Override
    public Class<?> loadClass(String name) throws ClassNotFoundException {
        return loadClass(name,false);
    }

    @Override
    public void close() throws IOException {
        super.close();
    }


}

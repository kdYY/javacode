package cn.sinobest.ggjs.strategy.core;

import java.io.File;
import java.lang.reflect.Constructor;
import java.util.HashMap;


import cn.sinobest.ggjs.strategy.AbstractService;
import cn.sinobest.ggjs.strategy.core.HotSpotSwap.StrategyClassLoader;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;
import org.apache.log4j.Logger;
import cn.sinobest.ggjs.strategy.AbstractStrategy;
import cn.sinobest.ggjs.strategy.core.utils.FileUtil;


public class CoreService extends AbstractService {

	private static final Logger LOGGER = Logger.getLogger(CoreService.class);

	
	public CoreService(PackageInfo packageInfo, StrategyInfo strategyInfo) {
		super(packageInfo,strategyInfo);
	}
	
	/**
	 * 实例化用户自定义编程Strategy
	 * @return
	 * @throws Exception
	 */
	private AbstractStrategy getStrategyInstance() throws Exception {
//       StrategyClassLoader strategyClassLoader = new StrategyClassLoader();
//       Class<?> strategyClass1 =strategyClassLoader.loadClass(strategyInfo.getStrategyName());
		Class<?> strategyClass1 =
				Class.forName(strategyInfo.getStrategyName());
		if (!(AbstractStrategy.class.isAssignableFrom(strategyClass1))) {
			throw new ClassCastException("error class type");
		}
		Constructor constructor = strategyClass1.getConstructor(new Class[] {PackageInfo.class, StrategyInfo.class});
		AbstractStrategy strategy = (AbstractStrategy) constructor.newInstance(new Object[] {packageInfo, strategyInfo});

		return strategy;
	}

	public PackageInfo execute() throws Exception {

		String oldJarPath = packageInfo.getPackagePath() + File.separator + packageInfo.getPackgeName();
		String ImpressTempPath = packageInfo.getTargetPath();
		String CompressDes = packageInfo.getTargetPath().substring(0, packageInfo.getTargetPath().lastIndexOf(File.separator)+1) + packageInfo.getPackgeName();

		File src = new File(oldJarPath);//jar存放的位置
		File des = new File(ImpressTempPath); //unJarpath


		//解压jar包
		FileUtil.unJar(src, des);
		LOGGER.info(src.getAbsolutePath() + "has finished");

		//执行策略
		AbstractStrategy strategy = this.getStrategyInstance();
		packageInfo = strategy.excute();
		LOGGER.info("strategy has finished");
//
//        StrategyClassLoader loader = (StrategyClassLoader)strategy.getClass().getClassLoader();
//        loader = null;
//        strategy = null;
//        System.gc();

        //打jar包 这里已经被占用
		String JarName = src.getName();
		String CompressSrc = ImpressTempPath + File.separator;
		FileUtil.compressJarByCommond(CompressSrc, CompressDes);
		LOGGER.info("package new jar has finished--" + CompressDes);

		// 尝试删除
//		Boolean result = FileUtil.deleteDir(des);
//		while(!result && des.exists()) {
//			System.gc();
//			result = FileUtil.deleteDir(des);
//            System.out.println("1+");
//		}
		
		return packageInfo;
	}

	public static void main(String[] args) throws Exception {
        PackageInfo packageInfo = new PackageInfo();
        packageInfo.setMainClass("cn.sinobest.sinogear.SinoGearExampleApp:main");
        packageInfo.setPackagePath("C:\\Users\\yaokaidong\\Desktop");
        packageInfo.setPackgeName("sim-manager-0.1.0-SNAPSHOT-exec.jar");
        packageInfo.setPackgeVersion("2.0");
        packageInfo.setTargetPath("C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-managr-0.1.0-SNAPSHOT-exec"); // 解压目录+jar名(sim-manager-0.1.0-SNAPSHOT-exec)
        StrategyInfo strategyInfo =new StrategyInfo();
        strategyInfo.setStrategyName("cn.sinobest.ggjs.strategy.basic.StrategyBasic");
        strategyInfo.setCertifiedDays(1000L);
        strategyInfo.setPrivateKey("MIIBSwIBADCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoEFgIUO8NDui56T9L8vFv0ArwsFtBgjkw=");//key要符合规范
        strategyInfo.setPublicKey("MIIBuDCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoDgYUAAoGBANDqOxNKcGcc3RZxnaAIuoARvMPv7mZy8O5FxlV3sCnQG4ya5pAngALWy/+97PTOroYGX/ifC5Thwq9YOR6szRoYd8fAdnrdxN4eh1r7Re9/VxV59N3MR3fpVK2+2a09MzHtRuyG7rkK+TVWN9o/aNh1Sk8Pf1HAKdSBWakoGnvT");
        strategyInfo.setVariables(new HashMap<String,String>());
        CoreService coreService = new CoreService(packageInfo, strategyInfo);
//        coreService.getStrategyInstance();
        coreService.execute();
    }
}

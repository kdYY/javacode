package cn.sinobest.ggjs.strategy.core.builder;

import cn.sinobest.ggjs.strategy.builder.AbstractBuilder;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;

public class EncryptedCodeBuilder extends AbstractBuilder {

	@Override
	public PackageInfo build() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

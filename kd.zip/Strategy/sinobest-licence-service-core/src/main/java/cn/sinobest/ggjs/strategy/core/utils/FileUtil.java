package cn.sinobest.ggjs.strategy.core.utils;

import java.io.*;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.jar.*;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;

import javax.management.RuntimeErrorException;

public class FileUtil {

    public static void copyFile(File src , File des) throws Exception{
        FileChannel input = null;
        FileChannel output = null;
        try {
            input = new FileInputStream(src).getChannel();
            output = new FileOutputStream(des).getChannel();
            output.transferFrom(input,0,input.size());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        } finally {
            try {
                if (input != null) {
                    input.close();
                }
                if (output != null) {
                    output.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    public static String copyJar(File src , File des) throws IOException {
        JarInputStream jarIn = new JarInputStream(new BufferedInputStream(new FileInputStream(src)));
        Manifest manifest = jarIn.getManifest();
        if(!des.getParentFile().exists()) des.getParentFile().mkdirs();

        JarOutputStream jarOut = null;
        if(manifest == null){
            jarOut = new JarOutputStream(new BufferedOutputStream(new FileOutputStream(des)));
        }else{
            jarOut = new JarOutputStream(new BufferedOutputStream(new FileOutputStream(des)),manifest);
        }

        byte[] bytes = new byte[1024 * 20];
        try {
            while(true){
                //重点
                ZipEntry entry = jarIn.getNextJarEntry();
                if(entry == null)
                    break;
                jarOut.putNextEntry(entry);

                int len = jarIn.read(bytes, 0, bytes.length);
                while(len != -1){
                    jarOut.write(bytes, 0, len);
                    len = jarIn.read(bytes, 0, bytes.length);
                }
            }
        } finally {
            jarIn.close();
            jarOut.finish();
            jarOut.close();
        }
        return des.getAbsolutePath();

    }

    public static String unJar(File src,File desDir) throws IOException {
        Long start = System.currentTimeMillis();
        JarFile jarFile = new JarFile(src);
        Enumeration<JarEntry> jarEntrys = jarFile.entries();
        if(!desDir.exists())
            desDir.mkdirs();

        byte[] bytes = new byte[1024 * 20];

        while(jarEntrys.hasMoreElements()){
            ZipEntry entryTemp = jarEntrys.nextElement();
            File desTemp = new File(desDir.getAbsolutePath() + File.separator + entryTemp.getName());

            if(entryTemp.isDirectory()){//目录
                if(!desTemp.exists())
                    desTemp.mkdir();

            }else {//文件
                File desTempParent = desTemp.getParentFile();
                if(!desTempParent.exists())desTempParent.mkdirs();

                BufferedInputStream in = null;
                BufferedOutputStream out = null;
                try {
                    in = new BufferedInputStream(jarFile.getInputStream(entryTemp));
                    out = new BufferedOutputStream(new FileOutputStream(desTemp));

                    int len = in.read(bytes, 0, bytes.length);
                    while(len != -1){
                        out.write(bytes, 0, len);
                        len = in.read(bytes, 0, bytes.length);
                    }
                } finally {//防止失败导致的内存泄露

                    if(in!=null)
                        in.close();
                    if(out!=null){
                        out.flush();
                        out.close();
                    }
                }
            }
        }
        Long end = System.currentTimeMillis();
        System.out.println((end-start)/1000+"s");
        return desDir.getAbsolutePath();
    }

    public static void compressJarByCommond(String CompressSrc,String CompressDes) throws IOException {
        Process process = null;
        try {
            String commond;
            String OS = System.getProperty("os.name").toLowerCase();

            File file = new File(CompressDes);
            if(!file.getParentFile().exists())
                file.getParentFile().mkdirs();

            if(OS.indexOf("linux") >= 0){
                commond = "jar -cfM0 "+CompressDes+" -C "+CompressSrc+" .";
                process = Runtime.getRuntime().exec(commond);
                process.waitFor();

            }else if(OS.indexOf("windows") >= 0){

                System.out.println("windows");
                String jarcomond = System.getProperty("java.home").substring(0,System.getProperty("java.home").indexOf("jre"))+"bin\\";
                commond = jarcomond+"jar -cfM0 "+CompressDes+" -C "+CompressSrc+" .";

                System.out.println("执行commond"+commond);
                process = Runtime.getRuntime().exec(commond);
            }else
                throw  new RuntimeException("your system is no support");
            int state = 0;
            if((state = process.waitFor()) != 0){
                System.out.println(state);
                throw  new RuntimeException("compressJar no success");
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }finally {
            process.destroy();
        }

    }




    private static void chooseAllFiles(File file , List<File> files){
        if(file.isDirectory()){
            for(File child : file.listFiles())
                chooseAllFiles(child,files);
        }else
            files.add(file);
    }

    public static boolean deleteDir(File someFile) {
        if (!someFile.exists()) {
            System.out.println("[deleteDir]File " + someFile.getAbsolutePath()
                    + " does not exist.");
            return false;
        }
        if (someFile.isDirectory()) {// is a folder
            File[] files = someFile.listFiles();
            for (File subFile : files) {
                boolean isSuccess = deleteDir(subFile);
                if (!isSuccess) {
                    System.out.println(subFile.getAbsolutePath()+"删除失败");
                    return isSuccess;
                }
            }
        } else {// is a regular file
            boolean isSuccess = someFile.delete();
            if (!isSuccess) {
                return isSuccess;
            }
        }
        if (someFile.isDirectory()) {
            return someFile.delete();
        } else {
            return true;
        }
    }

    /**
     * 删除文件，可以是文件或文件夹
     *
     * @param fileName
     *            要删除的文件名
     * @return 删除成功返回true，否则返回false
     */
    public static boolean delete(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            System.out.println("删除文件失败:" + fileName + "不存在！");
            return false;
        } else {
            if (file.isFile())
                return deleteFile(fileName);
            else
                return deleteDirectory(fileName);
        }
    }

    /**
     * 删除单个文件
     *
     * @param fileName
     *            要删除的文件的文件名
     * @return 单个文件删除成功返回true，否则返回false
     */
    public static boolean deleteFile(String fileName) {
        File file = new File(fileName);
        // 如果文件路径所对应的文件存在，并且是一个文件，则直接删除
        if (file.exists() && file.isFile()) {
            if (file.delete()) {
                System.out.println("删除单个文件" + fileName + "成功！");
                return true;
            } else {
                System.out.println("删除单个文件" + fileName + "失败！");
                return false;
            }
        } else {
            System.out.println("删除单个文件失败：" + fileName + "不存在！");
            return false;
        }
    }

    /**
     * 删除目录及目录下的文件
     *
     * @param dir
     *            要删除的目录的文件路径
     * @return 目录删除成功返回true，否则返回false
     */
    public static boolean deleteDirectory(String dir) {
        // 如果dir不以文件分隔符结尾，自动添加文件分隔符
        if (!dir.endsWith(File.separator))
            dir = dir + File.separator;
        File dirFile = new File(dir);
        // 如果dir对应的文件不存在，或者不是一个目录，则退出
        if ((!dirFile.exists()) || (!dirFile.isDirectory())) {
            System.out.println("删除目录失败：" + dir + "不存在！");
            return false;
        }
        boolean flag = true;
        // 删除文件夹中的所有文件包括子目录
        File[] files = dirFile.listFiles();
        for (int i = 0; i < files.length; i++) {
            // 删除子文件
            if (files[i].isFile()) {
                flag = FileUtil.deleteFile(files[i].getAbsolutePath());
                if (!flag)
                    break;
            }
            // 删除子目录
            else if (files[i].isDirectory()) {
                flag = FileUtil.deleteDirectory(files[i]
                        .getAbsolutePath());
                if (!flag)
                    break;
            }
        }
        if (!flag) {
            System.out.println("删除目录失败！");
            return false;
        }
        // 删除当前目录
        if (dirFile.delete()) {
            System.out.println("删除目录" + dir + "成功！");
            return true;
        } else {
            return false;
        }
    }




    public static ArrayList<String> findClassPath(String unJarpath) {
        File file = new File(unJarpath);
        if(!file.exists()){
            throw  new RuntimeException("classpath is empty");
        }
        ArrayList<String> classPaths = new ArrayList<String>();
        classPaths.add(unJarpath);
        findAllClassAndJarPath(classPaths,file);
        return classPaths;
    }

    private static void findAllClassAndJarPath(ArrayList<String> classPaths,File file) {
        if(file.isDirectory()){
            if(file.getName().indexOf("classes") >= 0){
                classPaths.add(file.getAbsolutePath());
            }
            for(File child : file.listFiles())
                findAllClassAndJarPath(classPaths,child);
        }else {
            if(file.getName().indexOf(".jar") >=0){
                classPaths.add(file.getAbsolutePath());
            }
        }
    }

    /**
     * find all path in file by the search name and saved in classPaths
     * @param classPaths
     * @param file
     * @param search
     */
    public static void findAllPath(HashSet<String> classPaths, File file, String search) {
        if(file.isDirectory()){
            for(File child : file.listFiles())
                findAllPath(classPaths,child,search);
            if(file.getName().indexOf(search) >=0){
                classPaths.add(file.getAbsolutePath());
            }
        }else {
            if( file.getName().indexOf(search) >=0 ){
                classPaths.add(file.getParentFile().getAbsolutePath());
            }
        }
    }
    /**
     * copy the verify jar to all possible path where the user project's lib in
     * @param srcFilePath
     * @param filePath
     * @param search
     * @param addName
     */
    public void copyExpand(String srcFilePath,String filePath,String search,String addName){
        HashSet<String> tempSet = new HashSet<>();
        //TODO 路径的通用性？？
        FileUtil.findAllPath(tempSet,new File(filePath),search);
        tempSet.forEach((e)->{
            String targetCopyPath = e + File.separator + addName;
            System.out.println("复制到"+targetCopyPath);
            try {
                FileUtil.copyFile(new File(srcFilePath), new File(targetCopyPath));
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }


    /*get the path where the running project's jar in
     *     
     */
    public static String getLibPath() {
    	return "/home/sonar/slc-libs/lib";
    	
//    	java.net.URL url = FileUtil.class.getProtectionDomain().getCodeSource()
//                .getLocation();
//        String filePath = null;
//        try {
//            filePath = java.net.URLDecoder.decode(url.getPath(), "utf-8");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        if (filePath.endsWith(".jar"))
//            filePath = filePath.substring(0, filePath.lastIndexOf("/") + 1);
//        File file = new java.io.File(filePath);
//        if(file.exists()) {
//        	return file.getAbsolutePath();
//        }else {
//			throw new RuntimeException("lib no exsit");
//		}
        
    }
    
    
    

}

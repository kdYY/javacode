package cn.sinobest.ggjs.offline.utils;

import cn.sinobest.ggjs.offline.builder.OffLineCopyBuilder;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.CountDownLatch;

public class OffLineFileUtil {

    public static void copyFileByURL(String urlPath , String des) throws  Exception{
//        InputStream is = OffLineFileUtil.class.getClassLoader().getResourceAsStream(urlPath);
        CountDownLatch countDownLatch;
        URL url = new URL(urlPath);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        //设置超时间为3秒
        conn.setConnectTimeout(3*1000);
        //得到输入流
        InputStream is = conn.getInputStream();

        //获取自己数组
        byte[] getData = readInputStream(is);

        //文件保存位置
        File file = new File(des);
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(getData);
        if(fos!=null){
            fos.close();
        }
        if(is!=null){
            is.close();
        }
    }

    /**
     * 从输入流中获取字节数组
     * @param inputStream
     * @return
     * @throws IOException
     */
    public static  byte[] readInputStream(InputStream inputStream) throws IOException {
        byte[] buffer = new byte[1024];
        int len = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while((len = inputStream.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }
        bos.close();
        return bos.toByteArray();
    }

    public static void findAllPath(HashSet<String> classPaths, File file,String search) {
        if(file.isDirectory()){
            for(File child : file.listFiles())
                findAllPath(classPaths,child,search);
            if(file.getName().indexOf(search) >=0){
                classPaths.add(file.getAbsolutePath());
            }
        }else {
            if( file.getName().indexOf(search) >=0 ){
                classPaths.add(file.getParentFile().getAbsolutePath());
            }
        }
    }

    public static boolean deleteDir(File someFile) {
        if (!someFile.exists()) {
            System.out.println("[deleteDir]File " + someFile.getAbsolutePath()
                    + " does not exist.");
            return false;
        }
        if (someFile.isDirectory()) {// is a folder
            File[] files = someFile.listFiles();
            for (File subFile : files) {
                boolean isSuccess = deleteDir(subFile);
                if (!isSuccess) {
                    System.out.println(subFile.getAbsolutePath()+"删除失败");
                    return isSuccess;
                }
            }
        } else {// is a regular file
            boolean isSuccess = someFile.delete();
            if (!isSuccess) {
                return isSuccess;
            }
        }
        if (someFile.isDirectory()) {
            return someFile.delete();
        } else {
            return true;
        }
    }



    public static void main(String[] args) {

        try {
            copyFileByURL("http://192.168.15.49:17077/files/test/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar","C:\\Users\\yaokaidong\\Desktop\\codejar\\sinobest-licence-service-core-0.0.1-SNAPSHOT.jar");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

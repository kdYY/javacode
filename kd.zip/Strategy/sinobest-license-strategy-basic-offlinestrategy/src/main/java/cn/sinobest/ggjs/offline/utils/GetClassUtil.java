package cn.sinobest.ggjs.offline.utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.concurrent.CountDownLatch;

public class GetClassUtil {

    static URLClassLoader myClassLoader;

    public static Class<?> getClassByNet(String path,String className,Class ParentClass) {
        URLClassLoader myClassLoader= null;
        Class<?> myClass= null;
        CountDownLatch countDownLatch;
        try {
            myClassLoader = new URLClassLoader(new URL[]{new URL(path)},
                    Thread.currentThread().getContextClassLoader());
//            throw  new ClassNotFoundException();
            myClass = myClassLoader.loadClass(className);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }catch (ClassNotFoundException e) {
            countDownLatch = new CountDownLatch(10);
            //自旋10次
            while(countDownLatch.getCount() > 0 && myClass == null){
                try {
                    myClassLoader =  new URLClassLoader(new URL[]{new URL(path)},
                            Thread.currentThread().getContextClassLoader());
                    myClass = myClassLoader.loadClass(className);
                } catch (ClassNotFoundException | MalformedURLException e1) {
                    try {
                        Thread.sleep(1000);

                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                } finally {
                    countDownLatch.countDown();
                }
            }
        }
        if(myClass == null){
            throw new ClassCastException("server error or your network error");
        }
        if (!ParentClass.isAssignableFrom(myClass)) {
            throw new ClassCastException("error class type to get");
        }
        return myClass;
    }
    /*private enum Single{
        SINGLECLASSLOADER("http://192.168.7.26:8082/api/file/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar");
        private URLClassLoader urlClassLoader;
        Single(String path){
            try {
                this.urlClassLoader = new URLClassLoader(new URL[]{new URL(path)},
                        Thread.currentThread().getContextClassLoader());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            ;
        }

    }*/

}

package cn.sinobest.ggjs.offline.test;

public abstract class abstracttest {
    int i;


    public abstracttest(int i) {
        this.i = i;
    }
}

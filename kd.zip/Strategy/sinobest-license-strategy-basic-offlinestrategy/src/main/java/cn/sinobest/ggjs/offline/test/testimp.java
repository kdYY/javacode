package cn.sinobest.ggjs.offline.test;

public class testimp extends abstracttest {

    public testimp(int i) {
        super(i);
    }

    public void init(){
        System.out.println(1616);
    }
}

package cn.sinobest.ggjs.offline;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * 将策略包jar用StrategyClassLoader进行加载，实现热卸载，
 * 2.0 版本实现热替换
 */
public class StrategyClassLoader extends URLClassLoader {

    private static String projectClassPath = Thread.currentThread().getContextClassLoader().getResource("").getFile();
//    private static String name = "cn.sinobest.ggjs.strategy.basic.StrategyBasic";

    public StrategyClassLoader() {
        super(getMyURLs());
    }

    private static  URL[] getMyURLs(){
        URL url = null;
        try {
            url = new File(projectClassPath).toURI().toURL();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return new URL[] { url };
    }

    @Override
    public Class<?> loadClass(String name,boolean resolve) throws ClassNotFoundException {
        Class clazz = null;
        //查看StrategyClassLoader实例缓存下，是否已经加载过class
        clazz = findLoadedClass(name);
        if (clazz != null ) {
            if (resolve){
                resolveClass(clazz);
            }
            return clazz;
        }

        //如果类的包名为"java."开始，则有系统默认加载器AppClassLoader加载
        if(name.startsWith("java.")){
            try {
                //得到系统默认的加载cl，即AppClassLoader
                ClassLoader system = ClassLoader.getSystemClassLoader();
                clazz = system.loadClass(name);
                if (clazz != null) {
                    if (resolve)
                        resolveClass(clazz);
                    return (clazz);
                }
            } catch (ClassNotFoundException e) {
                // Ignore
            }
        }
        //otherwise, using customload
        return customLoad(name,false,this);
    }
    /**
     * 自定义加载
     * @param name
     * @param resolve
     * @return
     * @throws ClassNotFoundException
     */
    public Class customLoad(String name, boolean resolve,ClassLoader cl) throws ClassNotFoundException {
        //findClass()调用的是URLClassLoader里面重载了ClassLoader的findClass()方法
        Class clazz = ((StrategyClassLoader)cl).findClass(name);
        if (resolve)
            ((StrategyClassLoader)cl).resolveClass(clazz);
        return clazz;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        // findClass实现了class文件搜索和load
        return super.findClass(name);
    }


}

package cn.sinobest.ggjs.offline.builder;


import cn.sinobest.ggjs.strategy.builder.AbstractBuilder;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;
import cn.sinobest.ggjs.offline.utils.OffLineFileUtil;

import java.io.*;
import java.util.HashSet;

import static cn.sinobest.ggjs.offline.utils.OffLineFileUtil.*;

public class OffLineCopyBuilder extends AbstractBuilder {

    public OffLineCopyBuilder(PackageInfo packageInfo, StrategyInfo strategyInfo) {
        this.packageInfo = packageInfo;
        this.strategyInfo = strategyInfo;
    }


    public PackageInfo build() throws Exception {
        String packagePath = this.packageInfo.getPackagePath();
        String targetPath = this.packageInfo.getTargetPath();
        String PackgeName = this.packageInfo.getPackgeName();
//        copy lic
//        String licFilePath = libPath +  File.separator + "license.lic";
//        copyExpand(licFilePath,targetPath,"classes","license.lic");
        String verifyJarName = "sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar";
        String urlPath = "http://192.168.15.49:17077/files/test/sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar";
        copyExpand(urlPath,targetPath,".jar",verifyJarName);
//      String targetVerifyFilePath = this.packageInfo.getTargetPath() + File.separator + "BOOT-INF" + File.separator + "lib" + File.separator + "sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar";
//        OffLineFileUtil.copyFile(new File(VerifyJarPath), new File(targetVerifyFilePath));
        return this.packageInfo;
    }

    /**
     * copy the verify jar to all possible path where the user project's lib in
     * @param verifyURLPath
     * @param filePath
     * @param search
     * @param addName
     */
    public void copyExpand(String verifyURLPath,String filePath,String search,String addName){
        HashSet<String> tempSet = new HashSet<>();
        //TODO 路径的通用性？？
        findAllPath(tempSet,new File(filePath),search);
        //下载太多次了
        tempSet.forEach((e)->{
            String targetCopyPath = e + File.separator + addName;
            System.out.println("复制到"+targetCopyPath);
            try {
                copyFileByURL(verifyURLPath, targetCopyPath);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }


    public static void main(String[] args) throws IOException {
        InputStream is=OffLineCopyBuilder.class.getClassLoader().getResourceAsStream("sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar");
        BufferedReader br=new BufferedReader(new InputStreamReader(is));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-manager-0.1.0-SNAPSHOT-exec\\BOOT-INF\\classes\\octopus\\oct.octopus\\oct.octopus\\lib\\sinobest-licence-strategy-basic-verify-0.0.1-SNAPSHOT.jar"))));
        String s="";
        while((s = br.readLine())!=null)
           bw.write(s,0,s.length()-1);
    }


}

package cn.sinobest.ggjs.offline.test;

import cn.sinobest.ggjs.strategy.AbstractStrategy;
import cn.sinobest.ggjs.strategy.builder.AbstractBuilder;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;
import cn.sinobest.ggjs.offline.utils.GetClassUtil;

import java.io.*;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class test {

    public test() {
        System.out.println("test");
    }

    public static void t(){
        System.out.println("t()");
    }

    public void moni() throws Exception {
       /* PackageInfo packageInfo = new PackageInfo();
        packageInfo.setMainClass("cn.sinobest.sinogear.SinoGearExampleApp:cn.sinobest.ggjs.offline.test.test2");
        packageInfo.setPackagePath("C:\\Users\\yaokaidong\\Desktop");
        packageInfo.setPackgeName("sim-manager-0.1.0-SNAPSHOT-exec.jar");
        packageInfo.setPackgeVersion("2.0");
        packageInfo.setTargetPath("C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-managr-0.1.0-SNAPSHOT-exeec");//解压目录+jar名(sim-manager-0.1.0-SNAPSHOT-exec)

        StrategyInfo strategyInfo = new StrategyInfo();
        strategyInfo.setStragegyName("cn.sinobest.ggjs.strategy.StrategyBasic");
        strategyInfo.setCertifiedDays(1000L);
        strategyInfo.setPrivateKey("MIIBSwIBADCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoEFgIUO8NDui56T9L8vFv0ArwsFtBgjkw=");//key要符合规范
        strategyInfo.setVariables(new HashMap<String,String>());
        CoreService coreService = new CoreService(packageInfo,strategyInfo);
        packageInfo = coreService.execute();*/

        URLClassLoader urlClassLoader = new URLClassLoader(
                new URL[]{new URL("http://192.168.7.26:8082/api/file/download?articleID=12&fileName=123")},
                Thread.currentThread().getContextClassLoader());

        InputStream resourceAsStream = urlClassLoader.getResourceAsStream("cn.sinobest.ggjs.builder.InjectCheckPointBuilder");
        System.out.println(resourceAsStream.toString());

        Class<?> clazz1 = urlClassLoader.loadClass("cn.sinobest.ggjs.builder.InjectCheckPointBuilder");


        System.out.println(clazz1.newInstance().toString());

        Class<?> clazz = URLClassLoader.newInstance(

                new URL[]{new URL("http://192.168.7.26:8082/api/file/download?articleID=12&fileName=123")})
                .loadClass("cn.sinobest.ggjs.builder.InjectCheckPointBuilder");

        if (!(clazz.newInstance() instanceof AbstractBuilder)) {
            throw new ClassCastException("error class type");
        } else {
            Constructor constructor = clazz.getConstructor(PackageInfo.class, StrategyInfo.class);
            AbstractStrategy strategy = (AbstractStrategy)constructor.newInstance("1","2","3","4","5");
            strategy.toString();
        }
    }

//    public static void cn.sinobest.ggjs.offline.test.test2(String[] args) throws Exception {
//
//        URLClassLoader myClassLoader=new URLClassLoader(new URL[]{new URL("http://192.168.7.26:8082/api/file/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar")},Thread.currentThread().getContextClassLoader());
//        Class<?> myClass=myClassLoader.loadClass("cn.sinobest.ggjs.strategy.core.builder.InjectCheckPointBuilder");
//        if (!(myClass.newInstance() instanceof AbstractBuilder)) {
//            throw new ClassCastException("error class type");
//        }else {
//            AbstractBuilder strategy = (AbstractBuilder) myClass.newInstance();
//            strategy.toString();
//        }
//    }

    public Class<?> getClassByNet(String path,String className,Class ParentClass) throws Exception {
        URLClassLoader myClassLoader=new URLClassLoader(new URL[]{new URL(path)},
                Thread.currentThread().getContextClassLoader());
        Class<?> myClass=myClassLoader.loadClass(className);
        if (!ParentClass.isAssignableFrom(myClass)) {
            throw new ClassCastException("error class type");
        }
        return myClass;
    }

    public static void main(String[] args) throws Exception {
        /*
            String path = "http://192.168.7.26:8082/api/file/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar";
            String className = "cn.sinobest.ggjs.strategy.core.builder.InjectCheckPointBuilder";
            Class builder = GetClassUtil.getClassByNet(path,className,AbstractBuilder.class);
            System.out.println(builder.newInstance().toString());
        */

//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        ObjectOutputStream oos = new ObjectOutputStream(baos);//创建一个对象输出流对象（对字节数组输出流对象的一个包装）
//
//        test.t();
//        test test = new test();
//        test.t();
        if (!cn.sinobest.ggjs.strategy.StrategyVerify.getInstance().isValid()){
            System.out.println("fail");
        }else {
            System.out.println("success");
        }



    }

    
}

package cn.sinobest.ggjs.offline.test;

public class question {
    public static void main(String[] args) {
        //用下面的复制会导致jar包受损
//        try {
//            is = url.openStream();
//        } catch (MalformedURLException e) {
//            countDownLatch = new CountDownLatch(10);
//            //自旋10次
//            while(countDownLatch.getCount() > 0 && is == null){
//                try {
//                    is = url.openStream();
//                } catch (MalformedURLException e1) {
//                    try {
//                        Thread.sleep(800);
//                    } catch (InterruptedException e2) {
//                        e2.printStackTrace();
//                    }
//                } finally {
//                    countDownLatch.countDown();
//                }
//            }
//            System.out.println("版本过旧");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        InputStreamReader inputStreamReader = new InputStreamReader(is);
//        BufferedReader br = new BufferedReader(inputStreamReader);
//
//        FileOutputStream fileOutputStream = new FileOutputStream(new File(des));
//        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fileOutputStream));
//
//        String s;
//        while((s=br.readLine())!=null)
//            bw.write(s,0,s.length()-1);
//
//        is.close();
//        br.close();
//        bw.close();
    }
}

package cn.sinobest.ggjs.offline.strategy;

import cn.sinobest.ggjs.offline.builder.OffLineCopyBuilder;
import cn.sinobest.ggjs.strategy.AbstractStrategy;
import cn.sinobest.ggjs.strategy.builder.AbstractBuilder;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;
import cn.sinobest.ggjs.offline.utils.GetClassUtil;

import java.io.File;
import java.lang.reflect.Constructor;
import java.net.MalformedURLException;
import java.util.Map;

public class OffLineStrategyBasic extends AbstractStrategy {

    public OffLineStrategyBasic(PackageInfo packageInfo, StrategyInfo strategyInfo) {
        super(packageInfo, strategyInfo);
        System.out.println("in");
        init();
    }


    public void init() {
        //将lic文件和验证jar复制到指定jar包
        OffLineCopyBuilder copyBuilder = new OffLineCopyBuilder(this.packageInfo, this.strategyInfo);
        this.addBuilder(copyBuilder);
        String JarDecompressTempDir = this.packageInfo.getTargetPath();
        String[] main = this.packageInfo.getMainClass().split(":");
        String className = main[0];
        String methodName = main[1];

        //TODO 用FileUtil搜索含有class的文件路径
        String outputPath = JarDecompressTempDir + File.separator + "BOOT-INF" + File.separator + "classes";

        String injectCode = "    \ttry {\n    \t\tif (!cn.sinobest.ggjs.strategy.StrategyVerify.getInstance().isValid()) {\n\tlogger.error(\"***********the license file is invalid (authentication is invalid or license file is expired), the system will exit!!!\");        \t\tSystem.exit(-1);\n    \t\t}\n    \t} catch (Throwable e) {\n\tlogger.error(\"***********the license file is invalid (authentication is invalid or license file is expired), the system will exit!!!\");    \t\tSystem.exit(-1);\n    \t}";
        String path = "http://192.168.15.49:17077/files/test/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar";
        String builderClass = "cn.sinobest.ggjs.strategy.core.builder.InjectCheckPointBuilder";
        AbstractBuilder injectCheckPointBuilder = null;
        try {
            Class builderClazz = GetClassUtil.getClassByNet(
                    path,builderClass,AbstractBuilder.class);
            Constructor constructor = builderClazz.getConstructor(
                    new Class[] {String.class,String.class,String.class,String.class,String.class});
            injectCheckPointBuilder = (AbstractBuilder) constructor
                    .newInstance(JarDecompressTempDir, className, methodName, injectCode, outputPath);
            System.out.println(JarDecompressTempDir+"--"+className+"--"+outputPath);
        } catch (Exception e) {
            throw new RuntimeException("retry");
        }
        this.addBuilder(injectCheckPointBuilder);
    }

    @Override
    public boolean isValid() throws Exception {
        return false;
    }

    @Override
    public Long daysLeft() throws Exception {
        return null;
    }

    @Override
    public String getVariables(String s) throws Exception {
        return null;
    }

    @Override
    public Map<String, String> createKey() {
        return null;
    }
}

package cn.sinobest.ggjs.offline;

import cn.sinobest.ggjs.offline.utils.OffLineFileUtil;
import cn.sinobest.ggjs.strategy.AbstractService;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;
import cn.sinobest.ggjs.offline.strategy.OffLineStrategyBasic;
import cn.sinobest.ggjs.offline.utils.GetClassUtil;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

public class App {

    //用户必须保证要做验证的jar的名称和在web上填写的名称一致
    public static void main(String[] args) {
        PackageInfo packageInfo = new PackageInfo();
        packageInfo.setMainClass(args[0]);//"cn.sinobest.sinogear.SinoGearExampleApp:main"
        packageInfo.setPackgeName(args[1]);//"sim-manager-0.1.0-SNAPSHOT-exec.jar"
        offLineMock1(packageInfo,new StrategyInfo());
    }
    public static void offLineMock1(PackageInfo packageInfo, StrategyInfo strategyInfo){
        packageInfo.setPackagePath(System.getProperty("user.dir"));
        //时间戳目录
        Long timestamp = System.currentTimeMillis();
        String randomTempFile = "tmp_"+timestamp.toString();
        File tempFile = new File(packageInfo.getPackagePath()+File.separator+randomTempFile);
        if(!tempFile.exists()){
            tempFile.mkdir();
        }
        String targetPath = tempFile.getAbsolutePath()+File.separator+packageInfo.getPackgeName().substring(0,packageInfo.getPackgeName().indexOf(".jar"));
        //解压目录+jar名(sim-manager-0.1.0-SNAPSHOT-exec)
        packageInfo.setTargetPath(targetPath);
        strategyInfo.setStrategyName(OffLineStrategyBasic.class.getName());
        Class ServiceClass = GetClassUtil.getClassByNet(
                "http://192.168.15.49:17077/files/test/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar",
                "cn.sinobest.ggjs.strategy.core.CoreService",
                AbstractService.class);
        try {
            AbstractService coreService = (AbstractService)ServiceClass.getConstructor(
                    new Class[]{PackageInfo.class,StrategyInfo.class}).
                    newInstance(packageInfo,strategyInfo);
            coreService.execute();
            //删除目标jar的中间文件
            OffLineFileUtil.deleteDir(new File(packageInfo.getTargetPath()));
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

//    public static void offLineMock(PackageInfo packageInfo, StrategyInfo strategyInfo){
//        packageInfo = new PackageInfo();
//        packageInfo.setMainClass("cn.sinobest.sinogear.SinoGearExampleApp:main");
//        packageInfo.setPackagePath("C:\\Users\\yaokaidong\\Desktop");
//        packageInfo.setPackgeName("sim-manager-0.1.0-SNAPSHOT-exec.jar");
//        packageInfo.setPackgeVersion("2.0");
//        //时间戳目录
//        Long timestamp = System.currentTimeMillis();
//        String randomTempFile = "tmp_"+timestamp.toString();
//        File tempFile = new File(packageInfo.getPackagePath()+File.separator+randomTempFile);
//        if(!tempFile.exists()){
//            tempFile.mkdir();
//        }
//        String targetPath = tempFile.getAbsolutePath()+File.separator+packageInfo.getPackgeName().substring(0,packageInfo.getPackgeName().indexOf(".jar"));
//        packageInfo.setTargetPath(targetPath);//解压目录+jar名(sim-manager-0.1.0-SNAPSHOT-exec)
//        strategyInfo.setStrategyName(OffLineStrategyBasic.class.getName());
//
//        Class ServiceClass = GetClassUtil.getClassByNet(
//                "http://192.168.15.49:17077/files/test/sinobest-licence-service-core-0.0.1-SNAPSHOT.jar",
//                "cn.sinobest.ggjs.strategy.core.CoreService",
//                AbstractService.class);
//        try {
//            AbstractService coreService = (AbstractService)ServiceClass.getConstructor(
//                    new Class[]{PackageInfo.class,StrategyInfo.class}).
//                    newInstance(packageInfo,strategyInfo);
//            coreService.execute();
//            //删除目标jar的中间文件
//            OffLineFileUtil.deleteDir(new File(packageInfo.getTargetPath()));
//        } catch (InstantiationException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (InvocationTargetException e) {
//            e.printStackTrace();
//        } catch (NoSuchMethodException e) {
//            e.printStackTrace();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//    }
}

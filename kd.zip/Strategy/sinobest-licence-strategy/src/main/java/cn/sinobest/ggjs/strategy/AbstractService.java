package cn.sinobest.ggjs.strategy;

import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;

public abstract class AbstractService {
	
	protected PackageInfo packageInfo;
	
	protected StrategyInfo strategyInfo;
	
	public AbstractService(PackageInfo packageInfo, StrategyInfo strategyInfo) {
		this.packageInfo = packageInfo;
		this.strategyInfo = strategyInfo;
	}
	
	public abstract PackageInfo execute() throws Exception;
	
}

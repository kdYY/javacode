package cn.sinobest.ggjs.strategy.test;

import java.io.File;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;

import cn.sinobest.ggjs.strategy.core.CoreService;
import cn.sinobest.ggjs.strategy.domain.PackageInfo;
import cn.sinobest.ggjs.strategy.domain.StrategyInfo;

public class TestStrategy {

	public void mock() throws Exception {
        PackageInfo packageInfo = new PackageInfo();
        packageInfo.setMainClass("cn.sinobest.sinogear.SinoGearExampleApp:main");
        packageInfo.setPackagePath("C:\\Users\\yaokaidong\\Desktop");
        packageInfo.setPackgeName("sim-manager-0.1.0-SNAPSHOT-exec.jar");
        packageInfo.setPackgeVersion("2.0");
        packageInfo.setTargetPath("C:\\Users\\yaokaidong\\Desktop\\codejar\\sim-managr-0.1.0-SNAPSHOT-exec"); // 解压目录+jar名(sim-manager-0.1.0-SNAPSHOT-exec)
        StrategyInfo strategyInfo =new StrategyInfo();
        strategyInfo.setStrategyName("cn.sinobest.ggjs.strategy.basic.StrategyBasic");
        strategyInfo.setCertifiedDays(1000L);
        strategyInfo.setPrivateKey("MIIBSwIBADCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoEFgIUO8NDui56T9L8vFv0ArwsFtBgjkw=");//key要符合规范
        strategyInfo.setPublicKey("MIIBuDCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoDgYUAAoGBANDqOxNKcGcc3RZxnaAIuoARvMPv7mZy8O5FxlV3sCnQG4ya5pAngALWy/+97PTOroYGX/ifC5Thwq9YOR6szRoYd8fAdnrdxN4eh1r7Re9/VxV59N3MR3fpVK2+2a09MzHtRuyG7rkK+TVWN9o/aNh1Sk8Pf1HAKdSBWakoGnvT");
        strategyInfo.setVariables(new HashMap<String,String>());
        CoreService coreService = new CoreService(packageInfo,strategyInfo);
        packageInfo = coreService.execute();
    }
    
    public static void main(String[] args) throws Exception {

//        String projectClassPath = Thread.currentThread().getContextClassLoader().getResource("").getFile();
//        System.out.println(Thread.currentThread().getContextClassLoader().getResource(""));
//        System.out.println(new File(projectClassPath).toURI().toURL());
//
//        URI uri = new URI(Thread.currentThread().getContextClassLoader().getResource("").getFile());
//        URLClassLoader urlClassLoader = new URLClassLoader(new URL[]{Thread.currentThread().getContextClassLoader().getResource("")});
//        System.out.println(urlClassLoader.loadClass("cn.sinobest.ggjs.strategy.test.TestStrategy").newInstance().toString());
        (new TestStrategy()).mock();
    }

    @Override
    public String toString() {
        return "test";
    }
}
